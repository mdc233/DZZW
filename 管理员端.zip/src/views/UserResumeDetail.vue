<template>
  <div class="resume-detail">
    <header class="header">
      <el-button size="small" @click="goBack">返回</el-button>
      <h2 class="title">简历详情</h2>
      <div class="status">{{statusText}}</div>
    </header>
    <section class="content">
      <div class="interview-info">
        <div class="flex-prop-value">
          <div class="item">
            <div class="it prop">ID:</div>
            <div class="it value">{{interviewInfo._id}}</div>
          </div>
          <div class="item">
            <div class="it prop">投递人姓名:</div>
            <div class="it value">{{interviewInfo.name}}</div>
          </div>
          <div class="item">
            <div class="it prop">投递岗位:</div>
            <div class="it value">{{interviewInfo.applyJob}}</div>
          </div>
          <div class="item">
            <div class="it prop">投递时间:</div>
            <div class="it value">{{normalizeDate(interviewInfo.deliveryTime)}}</div>
          </div>
        </div>
      </div>
      <div class="resume-info">
        <div class="title">简历</div>
        <div class="detail-wrapper">
          <div class="detail">
            <div class="flex-prop-value">
              <div class="item">
                <div class="it prop">姓名</div>
                <div class="it value">{{resumeInfo.name}}</div>
              </div>
              <div class="item">
                <div class="it prop">年级</div>
                <div class="it value">{{resumeInfo.grade}}</div>
              </div>
              <div class="item">
                <div class="it prop">院系</div>
                <div class="it value">{{resumeInfo.department}}</div>
              </div>
              <div class="item">
                <div class="it prop">专业</div>
                <div class="it value">{{resumeInfo.major}}</div>
              </div>
            </div>
            <div class="f-p-v">
                <div class="it prop">
                  项目经验
                </div>
                <div class="it value">
                  {{resumeInfo.projectExperience}}
                </div>
            </div>
            <div class="f-p-v">
                <div class="it prop">
                  简历附件
                </div>
                <div class="it value">
                  <a class="download-btn" :href="`/api/resume/download/${resumeInfo.resumeUrl}`" target="_blank">下载</a>
                </div>
            </div>
          </div>
        </div>
      </div>
      <div class="operate">
        <el-button :disabled="btnDisable" class="operate-btn" @click="overInterview">结束流程</el-button>
        <el-button :disabled="btnDisable" class="operate-btn" @click="circulateStatus">流转</el-button>
      </div>
    </section>
    <el-dialog :visible.sync="dialogVisible" width="25%">
      <span>{{dialogText}}</span>
      <div slot="footer">
        <el-button @click="cancel">取消</el-button>
        <el-button type="primary" @click="submit">确认</el-button>
      </div>
    </el-dialog>
    <div v-if="interviewDialogVisible">
      <interview-arrange-dialog :interview-info="interviewInfo" :visible.sync="interviewDialogVisible" @arrange-success="arrangeSuccess"></interview-arrange-dialog>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import InterviewArrangeDialog from '../components/InterviewArrangeDialog.vue'
import { getInterviewDetail, passInterview, overInterview } from '../api/interview'
import { getResumeInfo } from '../api/resume'
import { successMessage } from '../utils'

export default {
  created() {
    let { userId } = this.$route.params
    let { id } = this.$route.query
    this.userId = this.$route.params.userId
    this.id = id
    this.__getInterviewDetail(id)
    this.__getResumeInfo(userId)
  },
  components: {
    InterviewArrangeDialog
  },
  data() {
    return {
      id: '',
      userId: '',
      interviewInfo: {},
      resumeInfo: {},
      dialogVisible: false,
      operateText: '',
      operateStatuText: '',
      interviewDialogVisible: false,
      isPassOp: true
    }
  },
  computed: {
    statusText() {
      let statusText = ['待处理', '面试中', '已通过', '以结束']
      return statusText[this.interviewInfo.interviewStatus-1]
    },
    dialogText() {
      return `${this.operateText}后，简历的状态将变为【${this.operateStatuText}】，是否继续该操作`
    },
    btnDisable() {
      return this.interviewInfo.interviewStatus >= 3
    }
  },
  methods: {
    goBack() {
      this.$router.go(-1)
    },
    normalizeDate(value) {
      return dayjs(value).format('YYYY-MM-DD hh:mm')
    },
    overInterview() {
      this.dialogVisible = true
      this.operateText = '结束流程'
      this.operateStatuText = '已结束'
      this.isPassOp = false
    },
    cancel() {
      this.dialogVisible = false
    },
    submit() {
      if (this.isPassOp) {
        passInterview(this.interviewInfo._id).then(res => {
          if (res.code === 0) {
            successMessage('流转成功')
            this.dialogVisible = false
            this.__getInterviewDetail(this.id)
          }
        })
      } else {
         overInterview(this.interviewInfo._id).then(res => {
          if (res.code === 0) {
            successMessage('结束流程成功')
            this.dialogVisible = false
            this.__getInterviewDetail(this.id)
          }
        })
      }
    },
    circulateStatus() {
      if(this.interviewInfo.interviewStatus === 2) {
        this.dialogVisible = true
        this.operateText = '流转'
        this.operateStatuText = '已通过'
        this.isPassOp = true
      } else if (this.interviewInfo.interviewStatus === 0) {
        this.interviewDialogVisible = true
      }
    },
    arrangeSuccess() {
      successMessage('安排面试成功')
      this.interviewDialogVisible = false
      this.__getInterviewDetail(this.id)
    },
    __getInterviewDetail(id) {
      getInterviewDetail(id).then(res => {
        if (res.code === 0) {
          this.interviewInfo = res.data.interview
        }
      })
    },
    __getResumeInfo(userId) {
      getResumeInfo(userId).then(res => {
        if(res.code === 0) {
          this.resumeInfo = res.data.resume
        }
      })
    }
  }
}
</script>

<style scoped>

.resume-detail {
  color: #333;
}

.resume-detail .header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

.resume-detail .header .title {
  font-size: 27px;
  font-weight: bold;
}

.resume-detail .header .status {
  border-radius: 5px;
  width: 70px;
  height: 30px;
  text-align: center;
  line-height: 30px;
  color: #67C23A;
  background: #f0f9ec;
}

.interview-info {
  padding: 10px;
  background: #f2f2f2;
  margin-bottom: 20px;
}

.flex-prop-value {
  display: flex;
  flex-wrap: wrap;
  width: 85%;  
}

.flex-prop-value .item {
  display: flex;
  justify-content: space-between;
  margin: 12px 0;
  width: 40%;
}

.flex-prop-value .item  .it {
  width: 48%;
  font-size: 15px;
}

.flex-prop-value .item .prop {
  text-align: right;
}


.resume-info .title {
  margin-bottom: 10px;
  font-size: 20px;
  font-weight: bold;
}

.resume-info .detail-wrapper {
  border: 1px solid #333;
  margin-bottom: 10px;
  padding: 10px;
  min-height: 350px;
}

.resume-info .flex-prop-value .item {
  justify-content: flex-start;
  margin: 30px;
}

.resume-info .flex-prop-value .it {
  margin-right: 15px;
  width: 150px;
}

.resume-info .detail .f-p-v {
  display: flex;
  margin: 25px;
  width: 70%;
}

.resume-info .detail .f-p-v .prop {
  margin-right: 15px;
  flex: 0 0 150px;
  text-align: right;
}

.download-btn {
  display: block;
  border: 1px solid #333;
  border-radius: 5px;
  width: 80px;
  height: 20px;
  text-decoration: none;
  color: #333;
  text-align: center;
  line-height: 20px;
}

.operate  {
  text-align: right;
}

.operate .operate-btn {
  width: 100px;
}

</style>