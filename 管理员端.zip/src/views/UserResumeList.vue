<template>
  <div class="user-resume-list">
    <div class="screen-wrapper">
      <div class="screen">
        <el-row class="screen-list">
          <el-col :span="12" class="screen-item">
            <span class="label">投递岗位</span>
            <el-select v-model="jobId" placeholder="请选择">
              <el-option label="所有岗位" :value="-1"></el-option>
              <el-option
                v-for="item in jobOptions"
                :key="item.id"
                :label="item.title"
                :value="item.id">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="12" class="screen-item">
            <span class="label">环节状态</span>
            <el-select v-model="status" placeholder="请选择">
              <el-option label="所有环节" :value="-1"></el-option>
              <el-option
                v-for="item in statusOptions"
                :key="item.status"
                :label="item.statusText"
                :value="item.status">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-button @click="screenInterviewInfos">筛选</el-button>
      </div>
    </div>
    <div class="resume-list-wrapper">
      <el-tabs v-model="activeTab">
        <el-tab-pane label="未完成" name="not-complete">
          <div class="table-wrapper">
            <el-table @row-click="selectItem" class="resume-list" :data="unCompletedInterviewShowList">
              <el-table-column label="ID" type="index"></el-table-column>
              <el-table-column label="投递人姓名" prop="name"></el-table-column>
              <el-table-column label="投递岗位" prop="applyJob"></el-table-column>
              <el-table-column label="投递时间">
                <template slot-scope="scope">
                  {{normalizeDate(scope.row.deliveryTime)}}
                </template>
              </el-table-column>
              <el-table-column label="环节状态">
                <template slot-scope="scope">
                  <div class="select-time" @click="selectInterviewTime(scope.row, $event)" v-if="scope.row.interviewStatus === 1">选择面试时间</div>
                  <div class="interviewing" v-else-if="scope.row.interviewStatus === 2">面试中</div>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div>
            <el-pagination
              class="pagination"
              :page-size="count"
              :page-count="unCompletedPageCount"
              layout="prev, pager, next"
              @current-change="unCompletePageChange"
              >
            </el-pagination>
          </div>
        </el-tab-pane>
        <el-tab-pane label="已完成" name="complete">
          <div class="table-wrapper">
            <el-table @row-click="selectItem" class="resume-list" :data="completedInterviewShowList">
              <el-table-column label="ID" type="index"></el-table-column>
              <el-table-column label="投递人姓名" prop="name"></el-table-column>
              <el-table-column label="投递岗位" prop="applyJob"></el-table-column>
              <el-table-column label="投递时间">
                <template slot-scope="scope">
                  {{normalizeDate(scope.row.deliveryTime)}}
                </template>
              </el-table-column>
              <el-table-column label="环节状态">
                <template slot-scope="scope">
                  <div class="adopte" v-if="scope.row.interviewStatus === 3">
                    <el-tag type="info">已通过</el-tag>
                  </div>
                  <div class="over" v-if="scope.row.interviewStatus === 4">
                    <el-tag type="danger">已结束</el-tag>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div>
            <el-pagination
              class="pagination"
              :page-size="count"
              :page-count="completedPageCount"
              layout="prev, pager, next"
               @current-change="completePageChange"
              >
            </el-pagination>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div class="dialog-wrapper" v-if="dialogVisible">
      <interview-arrange-dialog :visible="dialogVisible" :interview-info="interviewInfo" @arrange-success="arrangeSuccess"></interview-arrange-dialog>
    </div>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import InterviewArrangeDialog from '../components/InterviewArrangeDialog.vue'
import {jobOptions, statusOptions} from '../config/options.js'
import {getInterviewList, getCompletedInterviewList, getUnCompletedInterviewList } from '../api/interview.js'
import { successMessage } from '../utils'
export default {
  created() {
    this.__getCompletedInterviewList()
    this.__getUnCompletedInterviewList()
  },
  components: {
    InterviewArrangeDialog
  },
  data() {
    return {
      jobOptions: jobOptions,
      jobId: '',
      statusOptions: statusOptions,
      status: '',
      completedPage: 1,
      unCompletedPage: 1,
      completedPageCount: 0,
      unCompletedPageCount: 0,
      completedPageTotal: 0,
      unCompletedPageTotal: 0,
      count: 5,
      interviewList: [],
      // completedInterviewList: [],
      // notCompletedInterviewList: [],
      activeTab: 'not-complete',
      interviewInfo: {},
      dialogVisible: false,
      interviewTime: 0,
      completedInterviewList: [],
      unCompletedInterviewList: []
    }
  },
  computed: {
    completedInterviewShowList() {
      return !this.status || this.status === -1 || this.status < 3
        ? this.completedInterviewList
        : this.completedInterviewList.filter(item => item.interviewStatus === this.status)
    },
    unCompletedInterviewShowList() {
      return !this.status || this.status === -1 || this.status >= 3
        ? this.unCompletedInterviewList
        : this.unCompletedInterviewList.filter(item => item.interviewStatus === this.status)
    }
  },
  methods: {
    screenInterviewInfos() {
      console.log(this.completedPageCount)
      this.__getCompletedInterviewList()
      this.__getUnCompletedInterviewList()
    },
    selectInterviewTime(interview, e) {
      this.interviewInfo = interview
      this.dialogVisible = true
      e.stopPropagation()
    },
    normalizeDate(date) {
      return dayjs(date).format('YYYY-MM-DD hh:mm')
    },
    selectItem(row, column, e) {
      let { userId } = row
      this.$router.push({
        path: `/resume/${userId}`,
        query: {
          id: row._id
        }
      })
    },
    completePageChange(page) {
      this.__getCompletedInterviewList(page)
    },
    unCompletePageChange(page) {
      this.__getUnCompletedInterviewList(page)
    },
    arrangeSuccess() {
      successMessage('安排面试成功')
      this.dialogVisible = false
      this.__getCompletedInterviewList()
      this.__getUnCompletedInterviewList()
    },
    __getCompletedInterviewList(page) {
      let params = {}
      params.count = this.count
      page && (params.page = page)
      if (this.jobId && this.jobId !== -1) {
        params.jobId = this.jobId
      }
      getCompletedInterviewList(params).then(res => {
        if (res.code === 0) {
          this.completedInterviewList = res.data.interviews
          let { total, count } = res.data
          let pageCount = parseInt(total / count)
          this.completedPageCount = total / count > pageCount ? pageCount + 1 : pageCount
        }
      })
    },
    __getUnCompletedInterviewList(page) {
      let params = {}
      params.count = this.count
      if (this.jobId && this.jobId !== -1) {
        params.jobId = this.jobId
      }
      page && (params.page = page)
      getUnCompletedInterviewList(params).then(res => {
        if (res.code === 0) {
          this.unCompletedInterviewList = res.data.interviews
           let { total, count } = res.data
          let pageCount = parseInt(total / count)
          this.unCompletedPageCount = total / count > pageCount ? pageCount + 1 : pageCount
        }
      })
    }
  }
}
</script>

<style scoped>
.user-resume-list .screen-wrapper {
  padding: 15px;
  margin-bottom: 20px;
  background: #f2f2f2
}

.user-resume-list .screen {
  margin: 0 auto;
  width: 90%;
  text-align: center;
}
.user-resume-list .screen .screen-list {
  margin-bottom: 20px;
}
.screen-list .screen-item .label {
  margin-right: 20px;
}

.resume-list .select-time {
  color: #409eff;
  cursor: pointer;
}

.resume-list .interviewing {
  border-radius: 5px;
  width: 70px;
  height: 30px;
  text-align: center;
  line-height: 30px;
  color: #67C23A;
  background: #f0f9ec;
}


.dialog-wrapper .interview-dialog .interview-info {
  font-size: 16px;
}

.interview-info .item {
  display: flex;
  padding: 15px;
}

.interview-info .item .prop {
  margin-right: 10px;
  flex: 0 0 120px;
  text-align: right;
}
 
.table-wrapper {
  min-height: 350px;
}

.pagination {
  text-align: center;
}
</style>