import Vue from 'vue'
import { Container, Aside, Main, Menu, MenuItem, Row, Col, Select, Option, FormItem, Button, Tabs, TabPane, Table, TableColumn, Dialog, DatePicker, Tag, Pagination } from 'element-ui'

Vue.use(Container).use(Aside).use(Main).use(Menu).use(MenuItem).use(Row).use(Col).use(Select).use(Option).use(FormItem).use(Button).use(Tabs).use(TabPane).use(Table).use(TableColumn).use(Dialog).use(DatePicker).use(Tag).use(Pagination)