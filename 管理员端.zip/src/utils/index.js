import { Message } from 'element-ui'

export function successMessage(message) {
  Message({
    type: 'success',
    message
  })
}

export function errorMessage(message) {
  Message({
    type: 'error',
    message
  })
}