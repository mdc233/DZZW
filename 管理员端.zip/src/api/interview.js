import request, {getRequest} from './request.js'

const getInterviewList = (params) => {
  return getRequest('/api/interview/list', params)
}

const getCompletedInterviewList = (params) => {
  return getRequest('/api/interview/completed', params)
}

const getUnCompletedInterviewList = (params) => {
  return getRequest('/api/interview/uncompleted', params)
}

const arrangeInterview = (id, interviewTime) => {
  return request('/api/interview/arrange', 'POST', {id, interviewTime})
}

const getInterviewDetail = (id) => {
  return request(`/api/interview/${id}`)
}

const passInterview = (id) => {
  return request('/api/interview/pass', 'POST', { id })
}

const overInterview = id => {
  return request('/api/interview/over', 'POST', { id })
}

export {
  getInterviewList,
  arrangeInterview,
  getInterviewDetail,
  passInterview,
  overInterview,
  getCompletedInterviewList,
  getUnCompletedInterviewList
}