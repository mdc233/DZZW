import request from './request'

const getResumeInfo = (userId) => {
  return request(`/api/resume/${userId}`)
}

export {
  getResumeInfo
}