import axios from 'axios'

const request = (url, method='GET', params={}) => {
  return axios({
    url,
    method,
    data: params
  }).then(res => {
    if (res.status === 200) {
      return res.data
    }
  })
}
export const getRequest = (url, params) => {
  return axios.get(url, {
    params,
  }).then(res => {
    if (res.status === 200) {
      return res.data
    }
  })
}
export default request