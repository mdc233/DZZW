const jobOptions =  [
  {
    id: 1,
    title: '前端'
  },
  {
    id: 2,
    title: '服务端'
  },
  {
    id: 3,
    title: '后台'
  },
  {
    id: 4,
    title: '产品经理'
  },
  {
    id: 5,
    title: '设计师'
  },
  {
    id: 6,
    title: '运营'
  }
]

const statusOptions = [
  {
    status: 1,
    statusText: '待处理'
  },
  {
    status: 2,
    statusText: '面试中'
  },
  {
    status: 3,
    statusText: '已完成'
  },
  {
    status: 4,
    statusText: '已结束'
  }
]

export {
  jobOptions,
  statusOptions
}