<template>
  <div id="app">
    <el-container class="container">
      <el-aside class="nav-side" width="120px">
        <sider-bar></sider-bar>
      </el-aside>
      <el-main class="main">
        <keep-alive include="UserResumeList">
          <router-view></router-view>
        </keep-alive>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import SiderBar from './components/SideBar.vue'
export default {
  name: 'app',
  components: {
    SiderBar
  }
}
</script>

<style>
html, body, #app, .container, .nav-side {
  height: 100%;
}

#app .main {
  padding: 15px;
}

</style>
