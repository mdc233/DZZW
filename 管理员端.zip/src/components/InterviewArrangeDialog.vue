<template>
  <el-dialog class="interview-dialog" title="面试安排" :visible="visible" width="40%" @close="close">
      <div class="interview-info">
        <div class="item">
          <span class="prop">面试岗位</span>
          <span class="value">{{interviewInfo.applyJob}}</span>
        </div>
        <div class="item">
          <span class="prop">面试地点</span>
          <span class="value">{{interviewInfo.interviewLoc}}</span>
        </div>
        <div class="item">
          <span class="prop">用户空闲时间</span>
          <span class="value">{{normalizeDate(interviewInfo.freeTime)}}</span>
        </div>
        <div class="item">
          <span class="prop">用户备注</span>
          <span class="value">{{interviewInfo.remark}}{{interviewInfo.remark}}{{interviewInfo.remark}}{{interviewInfo.remark}}{{interviewInfo.remark}}{{interviewInfo.remark}}{{interviewInfo.remark}}{{interviewInfo.remark}}{{interviewInfo.remark}}</span>
        </div>
        <div class="item">
          <span class="prop">确定面试时间为</span>
          <span class="value">
            <el-date-picker v-model="interviewTime" type="datetime"></el-date-picker>
          </span>
        </div>
      </div>
      <div slot="footer">
        <el-button @click="arrangeInterview">流转</el-button>
      </div>
    </el-dialog>
</template>

<script>
import dayjs from 'dayjs'
import {arrangeInterview} from '../api/interview.js'
export default {
  props: {
    interviewInfo: {
      type:Object,
      default: {}
    },
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      interviewTime: 0
    }
  },
  methods: {
    arrangeInterview() {
      let id = this.interviewInfo._id
      let interviewTime = this.interviewTime
      arrangeInterview(id, interviewTime).then(res => {
        if (res.code === 0) {
          this.$emit('arrange-success')
        }
      })
    },
    normalizeDate(value) {
      return dayjs(value).format('YYYY-MM-DD hh:mm')
    },
    close() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped>
.interview-info {
  font-size: 16px;
}

.interview-info .item {
  display: flex;
  padding: 15px;
}

.interview-info .item .prop {
  margin-right: 10px;
  flex: 0 0 120px;
  text-align: right;
}
</style>