<template>
  <div class="side-bar">
    <div class="avatar-wrapper">
      <img src="../assets/images/avatar.jpg" alt="头像" class="avatar">
      <span class="role">管理员</span>
    </div>
    <div class="menu-wrapper">
      <el-menu :router="true" class="nav-menu" default-active="/resume/list" background-color="#f2f2f2">
        <el-menu-item index="/resume/list">
          <div slot="title">
            简历概览
          </div>
        </el-menu-item>
        <el-menu-item index="/">
          <div slot="title">岗位描述</div>
        </el-menu-item>
      </el-menu>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.side-bar {
  height: 100%;
  padding: 10px 0;
  background: #f2f2f2;
  text-align: center;
  box-sizing: border-box;
}

.side-bar .avatar-wrapper {
   margin-bottom: 50px;
}

.side-bar .avatar-wrapper .avatar {
  display: block;
  margin: 0 auto;
  margin-bottom: 20px;
  width: 100px;
  height: 100px;
  border-radius: 50%;
}

.side-bar .avatar-wrapper .role {
  font-size: 18px;
}

.menu-wrapper .nav-menu {
  border: none;
}

</style>