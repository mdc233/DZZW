# matrix-apply

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).



### API

* 注册

  url: ` /user/register`

  method: `post`

  request:

  ```json
  email必需
  password 必需
  schoolNum必需
  name 必需
  ```

  response:

  ```
  {
      code: 0, 0表示成功,1表示出错
      data: {
          msg: '注册成功'
      }
  }
  ```

* 登录

  url: `/user/login`

  method: `post`

  request:

  ```
  email 必需
  password 必需
  ```

  response:

  ```
  {
      code: 0,
      data: {
          user:{
              id: 'xxx',
              name: 'xxx',
              schoolNum: 'xxx',
              email: 'xxx'
          }
      }
  }
  ```

  



