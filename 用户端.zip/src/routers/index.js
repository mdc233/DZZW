import Vue from 'vue'
import VueRouter from 'vue-router'
import { ifLogin } from '../utils'

Vue.use(VueRouter)

const router = new VueRouter({
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/home',
      component: () => import('@/views/Home.vue')
    },
    {
      path: '/login',
      component: () => import('@/views/Login.vue')
    },
    {
      path: '/register',
      component: () => import('@/views/Register.vue')
    },
    {
      path: '/user-center',
      component: () => import('@/views/UserCenter.vue')
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (to.path === '/user-center') {
    if (!ifLogin()) {
      next({
        path: '/login',
        query: {
          redirect: 'user-center'
        }
      })
    } else {
      next()
    }
  } else {
    next()
  }
})

export default router
