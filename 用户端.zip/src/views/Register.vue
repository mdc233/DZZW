<template>
  <div class="login">
    <el-container direction="vertical" class="container">
      <el-main>
        <div class="login-form">
          <span class="title">注 册</span>
          <el-form :model="formData" :rules="rules" ref="registerForm">
            <el-form-item prop="email" >
              <el-input v-model="formData.email" placeholder="请输入邮箱"></el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input type="password" v-model="formData.password" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-form-item prop="confirmPassword" >
              <el-input type="password" v-model="formData.confirmPassword" placeholder="请确认密码"></el-input>
            </el-form-item>
            <el-form-item prop="name">
              <el-input v-model="formData.name" placeholder="请输入姓名"></el-input>
            </el-form-item>
            <el-form-item prop="schoolNum">
              <el-input v-model="formData.schoolNum" placeholder="请输入学号"></el-input>
            </el-form-item>
          </el-form>
          <el-button type="primary" @click="doRegister" class="button">立即注册</el-button>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import { register } from '../api/user.js'
import { errorMessage } from '../utils'

export default {
  data () {
    return {
      formData: {
        email: '',
        password: '',
        confirmPassword: '',
        name: '',
        schoolNum: ''
      },
      rules: {
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/, message: '请输入正确的邮箱', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { pattern: /^[a-zA-Z]\w{7,}$/, message: '密码不符合规范, 字母开头, 字母、数字、_, 长度不小于8', trigger: 'blur' }
        ],
        confirmPassword: [
          { validator: this._confirmPasswordValidate, trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' }
        ],
        schoolNum: [
          { required: true, message: '请输入学号', trigger: 'blur' },
          { pattern: /^\d{8}$/, message: '请输入正确的学号', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    doRegister () {
      this.$refs['registerForm'].validate(valid => {
        if (valid) {
          let { email, password, name, schoolNum } = this.formData
          register(email, password, name, schoolNum).then(res => {
            if (res.code === 0) {
              this.$router.replace('/login')
            } else {
              errorMessage('服务器错误，请稍后重试')
            }
          })
        }
      })
    },
    _confirmPasswordValidate (rule, value, callback) {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.formData.password) {
        callback(new Error('两次输入密码不一致'))
      } else {
        callback()
      }
    }
  }
}
</script>

<style lang="less" scoped>
.login {
  height: 100%;
  background: #eee;
}
.el-container {
  padding: 0;
}
.el-main .login-form {
  margin: 100px auto;
  padding: 30px 20px;
  width: 300px;
  background: #fff;
  text-align: center;
  border-radius: 2px;
  box-shadow: 0 1px 3px rgba(0,0,0,.3)
}
.el-main .login-form .title {
  display: block;
  padding-bottom: 10px;
  height: 24px;
  line-height: 24px;
  font-size: 18px;
  color: #303133;
}
.el-main .login-form .button {
  margin-top: 20px;
  width: 100%;
}

.btn {
  padding: 9px;
}
</style>
