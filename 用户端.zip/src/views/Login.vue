<template>
  <div class="login">
    <el-container direction="vertical" class="container">
      <el-main>
        <div class="login-form">
          <span class="title">登 录</span>
          <el-form :model="formData" :rules="rules" ref="loginForm">
            <el-form-item prop="email" >
              <el-input v-model="formData.email" placeholder="请输入邮箱"></el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input type="password" v-model="formData.password" placeholder="请输入密码"></el-input>
            </el-form-item>
          </el-form>
          <span class="error-tip" v-if="showError">账号或密码错误</span>
          <el-button type="primary" @click="doLogin" class="button">确认登录</el-button>
          <div class="go-register">
            <router-link class="link" to="/register">没有账号? 去注册</router-link>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import { login } from '../api/user.js'
import { storeUserInfo } from '../utils'

export default {
  data () {
    return {
      showError: false,
      formData: {
        email: '',
        password: ''
      },
      rules: {
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/, message: '请输入正确的邮箱', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    doLogin () {
      this.$refs['loginForm'].validate(valid => {
        if (valid) {
          login(this.formData.email, this.formData.password).then(res => {
            if (res.code === 0) {
              storeUserInfo(res.data.user)
              let { redirect } = this.$route.query
              redirect ? this.$router.replace(`/${redirect}`) : this.$router.replace('/')
            } else {
              this.showError = true
            }
          })
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.login {
  height: 100%;
  background: #eee;
}
.el-container {
  padding: 0;
}
.el-main .login-form {
  margin: 100px auto;
  padding: 30px 20px;
  width: 300px;
  background: #fff;
  text-align: center;
  border-radius: 2px;
  box-shadow: 0 1px 3px rgba(0,0,0,.3)
}
.el-main .login-form .title {
  display: block;
  padding-bottom: 10px;
  height: 24px;
  line-height: 24px;
  font-size: 18px;
  color: #303133;
}
.el-main .login-form .button {
  margin-top: 20px;
  width: 100%;
}

.btn {
  padding: 9px;
}

.go-register {
  float: left;
  width: 100%;
  text-align: center;
}

.go-register .link {
  font-size: 14px;
  color: #409EFF;
  line-height: 40px;
}

.error-tip {
  font-size: 12px;
  color: red;
}
</style>
