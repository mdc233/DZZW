<template>
  <div class="home">
    <el-container class="container" direction="vertical">
      <m-header @login="showLoginDialog" class="m-header" @login-success="loginSuccess"></m-header>
      <el-main class="main">
        <div class="banner">
          <el-carousel height="200px">
            <el-carousel-item>
              <a class="carousel-1" href="https://mp.weixin.qq.com/s/PDd-y8fEZvGZRP0vg7D1_w" target="_blank"></a>
            </el-carousel-item>
            <el-carousel-item>
              <a class="carousel-2" href="https://www.wjx.top/m/32633980.aspx" target="_blank"></a>
            </el-carousel-item>
            <el-carousel-item>
              <a class="carousel-3" href="https://mp.weixin.qq.com/s/ngRU_PoP-2WJjFNgXko_PQ" target="_blank"></a>
            </el-carousel-item>
          </el-carousel>
        </div>
        <div class="job-wrapper">
          <el-container>
            <el-aside width="150px">
              <el-menu default-active="0" @select="selectItem">
                <el-menu-item index="0">前端</el-menu-item>
                <el-menu-item index="1">服务端</el-menu-item>
                <el-menu-item index="2">后台</el-menu-item>
                <el-menu-item index="3">产品经理</el-menu-item>
                <el-menu-item index="4">设计师</el-menu-item>
                <el-menu-item index="5">运营</el-menu-item>
              </el-menu>
            </el-aside>
            <el-main class="job-info">
              <h2>{{jobInfo.jobTitle}}</h2>
              <div class="line"></div>
              <div class="section">
                <span>岗位描述:</span>
                <pre>
{{jobInfo.jobDesc}}
                </pre>
              </div>
              <div class="section">
                <span>岗位要求: </span>
                <pre>
{{jobInfo.jobRequirement}}
                </pre>
              </div>
              <el-button :disabled="buttonDisable" type="primary" @click="deliverResume">投递简历</el-button>
            </el-main>
          </el-container>
        </div>
      </el-main>
    </el-container>
    <div class="tipDialogWrapper" v-if="tipDialogVisible">
      <el-dialog :visible.sync="tipDialogVisible" width="20%" class="tipDialog">
        <div class="tipText">{{tipDialogInfo.tip}}</div>
        <router-link :to="tipDialogInfo.route">
          <el-button type="primary" size="small">{{tipDialogInfo.routeText}}</el-button>
        </router-link>
      </el-dialog>
    </div>
    <div class="deliveryDialogWrapper" v-if="deliveryDialogVisible">
      <el-dialog :visible.sync="deliveryDialogVisible" class="deliveryDialog" width="30%">
        <div class="content">
          <span>您要投递的岗位是【{{jobTitle}}开发】</span>
          <el-dialog title="面试安排(一经提交不得修改)" :visible.sync="innerDeliveryDialogVisible" class="innerDeliveryDialog" width="40%" append-to-body>
            <el-form :model="interviewForm" ref="interviewForm" label-width="120px" :rules="interviewFormRule">
              <el-form-item label="投递人姓名" prop="name">
                <el-input v-model="interviewForm.name" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="面试岗位">
                <el-input v-model="interviewForm.applyJob" autocomplete="off" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item label="面试地点">
                <el-input v-model="interviewForm.interviewLoc" autocomplete="off" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item label="近期空闲时间" prop="freeTime">
                <el-date-picker v-model="interviewForm.freeTime" type="datetime"></el-date-picker>
              </el-form-item>
              <el-form-item label="备注">
                <el-input v-model="interviewForm.remark" autocomplete="off" type="textarea"></el-input>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="innerDeliveryDialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="submitInterviewForm">提 交</el-button>
            </div>
          </el-dialog>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button @click="deliveryDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="innerDeliveryDialogVisible = true">确 定 投 递</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import MHeader from '@/components/MHeader/MHeader.vue'
import jobInfos from '../config/job-desc.js'
import { ifLogin, getUserInfo, successMessage, storeUserInfo } from '../utils'
import { deliverResume } from '../api/interview'
export default {
  name: 'home',
  created () {
    this.jobInfo = this.jobInfos[0]
    this.ifLogin = ifLogin()
    let basicUserInfo = getUserInfo()
    if (basicUserInfo) {
      this.basicUserInfo = basicUserInfo
      this.isCreateResume = basicUserInfo.isCreateResume
      this.userId = basicUserInfo.id
    }
  },
  components: {
    MHeader
  },
  data () {
    return {
      userId: '',
      jobInfo: {},
      jobInfos: jobInfos,
      dialogVisible: false,
      ifLogin: false,
      isCreateResume: false,
      tipDialogVisible: false,
      tipDialogInfo: {
        tip: '',
        routeText: '',
        route: ''
      },
      basicUserInfo: {},
      deliveryDialogVisible: false,
      jobTitle: '',
      innerDeliveryDialogVisible: false,
      interviewForm: {
        jobId: 0,
        name: '',
        applyJob: '',
        interviewLoc: '数据科学与计算机学院',
        freeTime: 0,
        remark: ''
      },
      interviewFormRule: {
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' }
        ],
        freeTime: [
          { required: true, message: '请输入近期空闲时间', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    buttonDisable () {
      return this.basicUserInfo.jobIds && this.basicUserInfo.jobIds.indexOf(this.jobInfo.id) !== -1
    }
  },
  methods: {
    showLoginDialog () {
      this.dialogVisible = true
    },
    cancel () {
      this.dialogVisible = false
    },
    selectItem (index, indexPath) {
      this.jobInfo = jobInfos[index]
    },
    loginSuccess () {
      this.ifLogin = true
      let user = getUserInfo()
      this.isCreateResume = user.isCreateResume
      this.basicUserInfo = user
    },
    deliverResume () {
      if (!this.ifLogin) {
        this.tipDialogVisible = true
        this.tipDialogInfo.tip = '请登陆后操作'
        this.tipDialogInfo.routeText = '登录'
        this.tipDialogInfo.route = '/login'
      } else if (!this.isCreateResume) {
        this.tipDialogVisible = true
        this.tipDialogInfo.tip = '进入个人中心创建简历'
        this.tipDialogInfo.routeText = '确定'
        this.tipDialogInfo.route = '/user-center'
      } else {
        this.deliveryDialogVisible = true
        this.jobTitle = this.jobInfo.jobTitle
        this.interviewForm.applyJob = this.jobInfo.jobTitle
        this.interviewForm.jobId = this.jobInfo.id
      }
    },
    submitInterviewForm () {
      this.$refs['interviewForm'].validate(valid => {
        if (valid) {
          let userId = this.userId
          let params = { userId, ...this.interviewForm }
          deliverResume(params).then(res => {
            if (res.code === 0) {
              successMessage('投递成功')
              this.deliveryDialogVisible = false
              this.innerDeliveryDialogVisible = false
              this.basicUserInfo.jobIds.push(this.interviewForm.jobId)
              storeUserInfo(this.basicUserInfo)
            }
          })
        }
      })
    }
  }
}
</script>

<style scoped>
/* .m-header {
  position: fixed;
  box-sizing: content-box;
  padding: 0 0 5px 0;
  width: 100%;
  z-index: 2040;
} */

.home .main {
  padding:  0;
}

.el-carousel .el-carousel__item a{
  display: inline-block;
  width: 100%;
  height: 100%;
  background-size: cover;
}

.carousel-1 {
  background-image: url('../assets/images/joinUs.png');
}

.carousel-2 {
  background-image: url('../assets/images/feedBack.png');
}

.carousel-3 {
  background-image: url('../assets/images/userGuide.png');
}

.job-wrapper .el-aside {
  border: 1px solid #797979;
}

.el-aside .el-menu {
  border-right: none;
}

.el-main .job-wrapper {
  margin: 20px auto;
  width: 92%;
}

.job-wrapper .job-info {
  position: relative;
  border: 1px solid #797979;
  margin-left: 20px;
  min-height: 600px;
}

.job-info .job-title {
  font-size: 18px;
}

.job-info .line {
  margin-top: 20px;
  width: 100%;
  height: 1px;
  background: #797979;
}

.job-info .section {
  margin-top: 20px;
}

.job-info .section span {
  font-size: 18px;
  font-weight: bold;
}

.job-info .section pre {
    border: none;
    background: none;
    margin-top: 10px;
    font-size: 14px;
    color: rgba(0,0,0,.85);
    line-height: 30px;
    font-weight: 400;
    padding-left: 10px
}

.job-info .el-button {
  position: absolute;
  right: 10px;
  bottom: 10px;
}

.tipDialog {
  text-align: center;
}

.tipDialog .tipText {
  margin-bottom: 20px;
  font-size: 16px;
}

.deliveryDialog .content {
  text-align: center;
}
</style>
