<template>
  <el-container direction="vertical" class="user-center">
    <m-header></m-header>
    <el-main class="main">
      <el-container class="user-info" v-if="hasResume || isAddResume">
        <el-main class="resume-info">
          <h3 class="title">我的简历</h3>
          <el-button class="edit-resume" @click="saveOrEdit">{{isEdit ? '保存简历' : '编辑简历'}}</el-button>
          <div class="user-information-wrapper" v-if="!isEdit">
            <div class="user-infomation">
              <div class="basic-info">
                <span class="prop">姓名: </span>
                <span class="value">{{resumeInfo.name}}</span>
                <span class="prop">年级: </span>
                <span class="value">{{resumeInfo.grade}}</span>
              </div>
              <div class="basic-info">
                <span class="prop">院系: </span>
                <span class="value">{{resumeInfo.department}}</span>
                <span class="prop">专业: </span>
                <span class="value">{{resumeInfo.major}}</span>
              </div>
              <div class="project-experience">
                <span class="prop">项目经验: </span>
                <span class="value">{{resumeInfo.projectExperience}}</span>
              </div>
            </div>
          </div>
          <div class="edit-panel-wrapper" v-else>
            <div class="edit-panel">
              <el-form  label-width="100px" :model="resumeInfo" :rules="rules" ref="resumeForm">
                <div class="basic-info">
                  <div>
                    <el-form-item label="姓名" prop="name">
                      <el-input placeholder="请输入姓名" v-model="resumeInfo.name"></el-input>
                    </el-form-item>
                  </div>
                  <div>
                    <el-form-item label="年级" prop="grade">
                      <el-input placeholder="请输入年级" v-model="resumeInfo.grade"></el-input>
                    </el-form-item>
                  </div>
                </div>
                <div class="basic-info">
                  <div>
                    <el-form-item label="院系" prop="department">
                      <el-input placeholder="请输入院系" v-model="resumeInfo.department"></el-input>
                    </el-form-item>
                  </div>
                  <div>
                    <el-form-item label="专业" prop="major">
                      <el-input placeholder="请输入专业" v-model="resumeInfo.major"></el-input>
                    </el-form-item>
                  </div>
                </div>
                <el-form-item label="项目经验">
                  <el-input type="textarea" rows="4" v-model="resumeInfo.projectExperience"></el-input>
                </el-form-item>
                <el-form-item label="实习经历">
                  <el-input type="textarea" rows="4" v-model="resumeInfo.internshipExperience"></el-input>
                </el-form-item>
                <el-form-item label="校园活动经历">
                  <el-input type="textarea" rows="4" v-model="resumeInfo.campusActivityExperience"></el-input>
                </el-form-item>
                <el-form-item label="自身技能">
                  <el-input type="textarea" rows="4" v-model="resumeInfo.skill"></el-input>
                </el-form-item>
                <el-form-item label="自我评价">
                  <el-input type="textarea" rows="4" v-model="resumeInfo.selfEvaluation"></el-input>
                </el-form-item>
                <el-form-item label="附件简历">
                  <el-upload :action="uploadPath" :on-success="handleSuccess">
                    <el-button size="small">点击上传</el-button>
                  </el-upload>
                  <a v-if="resumeInfo.resumeUrl" class="resume-url" target="_blank" :href="resumeUrl">简历附件</a>
                </el-form-item>
              </el-form>
              <div class="btn-container">
                <el-button class="btn" type="primary" @click="saveUserInfo">保存</el-button>
              </div>
            </div>
          </div>
        </el-main>
        <el-aside class="user-interview-info">
          <h3 class="title">我的投递</h3>
          <div class="interview-state-wrapper">
            <div class="interview-state" v-for="item in interviewInfos" :key="item._id">
              <div class="job">
                岗位: {{item.applyJob}}
              </div>
              <div class="procedure">
                环节: {{statusText(item.interviewStatus)}}
              </div>
              <div class="interview-time" v-if="item.interviewStatus === 1">
                面试时间: {{ item.interviewTime | normalizeDate}}
              </div>
              <div class="interview-loc" v-if="item.interviewStatus === 1">
                面试地点: {{item.interviewLoc}}
              </div>
            </div>
          </div>
        </el-aside>
      </el-container>
      <el-button class="add-resume" @click="addResume" v-else>新建简历</el-button>
    </el-main>
  </el-container>
</template>

<script>
import dayjs from 'dayjs'
import MHeader from '../components/MHeader/MHeader.vue'
import { getUserInfo, storeUserInfo, successMessage } from '../utils'
import { addResume, getResumeInfo, updateResumeInfo } from '../api/resume.js'
import { getInterviewInfoByUserId } from '../api/interview.js'

export default {
  components: {
    MHeader
  },
  data () {
    return {
      userId: '',
      interviewInfos: null,
      basicUserInfo: null,
      hasResume: false,
      isAddResume: false,
      isEdit: false,
      resumeInfo: {
        name: '',
        grade: '',
        department: '',
        major: '',
        projectExperience: '',
        internshipExperience: '',
        campusActivityExperience: '',
        skill: '',
        selfEvaluation: '',
        resumeUrl: ''
      },
      rules: {
        name: [
          { required: true, message: '请输入姓名', 'trigger': 'blur' }
        ],
        grade: [
          { required: true, message: '请输入年级', 'trigger': 'blur' }
        ],
        department: [
          { required: true, message: '请输入院系', 'trigger': 'blur' }
        ],
        major: [
          { required: true, message: '请输入专业', 'trigger': 'blur' }
        ]
      }
    }
  },
  created () {
    let basicUserInfo = getUserInfo()
    if (basicUserInfo) {
      this.basicUserInfo = basicUserInfo
      let isCreateResume = basicUserInfo.isCreateResume
      let userId = basicUserInfo.id
      if (isCreateResume) {
        getResumeInfo(userId).then(res => {
          if (res.code === 0) {
            let resume = res.data.resume
            this.resumeInfo.name = resume.name
            this.resumeInfo.grade = resume.grade
            this.resumeInfo.department = resume.department
            this.resumeInfo.major = resume.major
            this.resumeInfo.projectExperience = resume.projectExperience
            this.resumeInfo.internshipExperience = resume.internshipExperience
            this.resumeInfo.campusActivityExperience = resume.campusActivityExperience
            this.resumeInfo.skill = resume.skill
            this.resumeInfo.selfEvaluation = resume.selfEvaluation
            this.resumeInfo.resumeUrl = resume.resumeUrl
          }
        })
        getInterviewInfoByUserId(userId).then(res => {
          if (res.code === 0) {
            this.interviewInfos = res.data.interviews
          }
        })
      }
      this.hasResume = isCreateResume
      this.userId = userId
    }
  },
  computed: {
    uploadPath () {
      return `/api/resume/upload?userId=${this.basicUserInfo.id}`
    },
    resumeUrl () {
      return `/api/resume/download/${this.userId}`
    }

  },
  filters: {
    normalizeDate (value) {
      return dayjs(value).format('YYYY-MM-DD hh:mm')
    }
  },
  methods: {
    statusText (status) {
      let statusTexts = ['待处理', '面试中', '已完成', '以结束']
      return statusTexts[status - 1]
    },
    addResume () {
      this.isAddResume = true
      this.isEdit = true
    },
    saveUserInfo () {
      this.__saveUserInfo()
    },
    handleSuccess (res, file, fileList) {
      if (res.code === 0) {
        this.resumeInfo.resumeUrl = this.userId
      }
    },
    saveOrEdit () {
      if (this.isEdit) {
        this.__saveUserInfo()
      } else {
        this.isEdit = !this.isEdit
      }
    },
    __saveUserInfo () {
      this.$refs['resumeForm'].validate(valid => {
        if (valid) {
          let params = { userId: this.userId, ...this.resumeInfo }
          if (this.hasResume) {
            updateResumeInfo(params).then(res => {
              if (res.code === 0) {
                this.isEdit = !this.isEdit
                successMessage('修改简历成功')
              }
            })
          } else {
            addResume(params).then(res => {
              if (res.code === 0) {
                this.hasResume = true
                this.basicUserInfo.isCreateResume = true
                storeUserInfo(this.basicUserInfo)
                successMessage('添加简历成功')
                this.isAddResume = false
                this.isEdit = false
              }
            })
          }
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.el-main {
  padding: 0;
}

.main {
  margin: 0 auto;
  padding: 25px 0;
  width: 92%;
}

.user-info .title {
  display: inline-block;
  text-align: left;
}

.user-info .resume-info  {
  margin-right: 55px;
}
.user-info .resume-info .edit-resume {
  float: right;
  padding: 5px;
}

.user-info .resume-info .user-information-wrapper {
  margin-top: 30px;
  height: 600px;
  border: 1px solid #797979;
}

.resume-info .user-information-wrapper .user-infomation {
  margin: 0 auto;
  width: 80%;
}

.resume-info .user-infomation .basic-info {
  margin: 35px 0;
}

.resume-info .user-infomation span.prop {
  display: inline-block;
  width: 15%;
  text-align: right;
  vertical-align: top;
}

.resume-info .user-infomation .basic-info span.value {
  display: inline-block;
  margin-left: 10px;
  width: 30%;
  text-align: left;
}

.resume-info .user-infomation .project-experience {
  margin-top: 10px;
}

.resume-info .user-infomation .project-experience .value {
  display: inline-block;
  margin-left: 10px;
  width: 70%;
}

.user-info .user-interview-info .interview-state-wrapper {
  margin-top: 30px;
}

.user-info .user-interview-info .interview-state {
  border: 1px solid #797979;
  margin-bottom: 25px;
  padding: 20px 10px 0;
}

.user-info .user-interview-info .interview-state > div {
  margin-bottom: 20px;
}
.add-resume {
  display: block;
  margin: 0 auto;
}

.edit-panel-wrapper {
  margin-top: 30px;
  border: 1px solid #797979;
}

.edit-panel-wrapper .edit-panel {
  width: 95%;
  margin: 20px auto;
}

.edit-panel .basic-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.edit-panel .basic-info > div {
  width: 45%;
}

.edit-panel .btn-container {
  height: 30px;
}

.edit-panel .btn-container .btn {
  float: right;
  padding: 9px;
  width: 80px;
}

.edit-panel .resume-url {
  font-size: 14px;
  color: #409EFF;
}

</style>
