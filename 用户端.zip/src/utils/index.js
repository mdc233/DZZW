import { Message } from 'element-ui'
const USER_KEY = '__MATRIX_USER__'
const LOGIN_KEY = '__LOGIN_KEY__'
export function storeUserInfo (user) {
  localStorage.setItem(USER_KEY, JSON.stringify(user))
  localStorage.setItem(LOGIN_KEY, 1)
}

export function getUserInfo () {
  let user = localStorage.getItem(USER_KEY)
  if (user) {
    return JSON.parse(user)
  }
  return null
}

export function removeUserInfo () {
  localStorage.removeItem(USER_KEY)
  localStorage.removeItem(LOGIN_KEY)
}

export function ifLogin () {
  return localStorage.getItem(LOGIN_KEY) === '1'
}

export function successMessage (message) {
  Message({
    message,
    type: 'success'
  })
}

export function errorMessage (message) {
  Message({
    message,
    type: 'error'
  })
}
