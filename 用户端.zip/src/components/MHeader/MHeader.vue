<template>
  <el-header class="header">
    <div class="header-content">
      <div class="logo-container">
        <img class="logo" src="../../assets/images/logo2-transparent-2x.svg" alt="">
      </div>
      <div class="nav">
        <ul class="nav-list">
          <li class="nav-item">
            <router-link to="/home">招聘岗位</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/">关于我们</router-link>
          </li>
          <li class="nav-item" v-if="ifLogin">
            <el-dropdown>
              <span class="dropdown-link">个人中心 <i class="el-icon-arrow-down el-icon--right"></i></span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>
                  <router-link to="/user-center">个人中心</router-link>
                </el-dropdown-item>
                <el-dropdown-item>
                  <div @click="logout">退出登录</div>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </li>
          <li class="nav-item" v-else @click="goLogin">
            登录
          </li>
        </ul>
      </div>
    </div>
    <div class="dialog-wrapper" v-if="dialogVisible">
      <el-dialog
        title="登录"
        :visible.sync="dialogVisible"
        width="30%"
        >
        <el-form :model="formData" :rules="rules" ref="loginForm">
          <el-form-item prop="email">
            <el-input v-model="formData.email" placeholder="请输入邮箱"></el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input type="password" v-model="formData.password" placeholder="请输入密码">
            </el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <div class="go-register">
            <router-link class="link" to="/register">没有账号? 去注册</router-link>
          </div>
          <el-button @click="dialogVisible=false">取 消</el-button>
          <el-button type="primary" @click="doLogin">提 交</el-button>
        </span>
      </el-dialog>
    </div>
  </el-header>
</template>

<script>
import { removeUserInfo, storeUserInfo, ifLogin } from '../../utils'
import { login } from '../../api/user'
export default {
  created () {
    this.ifLogin = ifLogin()
  },
  data () {
    return {
      ifLogin: false,
      dialogVisible: false,
      formData: {
        email: '',
        password: ''
      },
      rules: {
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          { pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/, message: '请输入正确的邮箱', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    logout () {
      removeUserInfo()
      this.ifLogin = false
      this.$router.replace('/')
    },
    doLogin () {
      this.$refs['loginForm'].validate(valid => {
        if (valid) {
          let { email, password } = this.formData
          login(email, password).then(res => {
            if (res.code === 0) {
              storeUserInfo(res.data.user)
              this.ifLogin = true
              this.dialogVisible = false
              this.$emit('login-success')
            }
          })
        }
      })
    },
    goLogin () {
      this.dialogVisible = true
    }
  }
}
</script>

<style lang="less" scoped>
.header {
  padding: 0 0 5px 0;
  box-sizing: content-box;
  background-color: #409EFF;
}

.header .header-content {
  margin: 0 auto;
  width: 92%;
}

.header .logo-container {
  display: inline-block;
  height: 60px;
  line-height: 60px;
}

.header .header-content .logo {
  display: inline-block;
  height: 90%;
  vertical-align: middle;
}
.header .header-content .nav {
  float: right;
}

.header .nav .nav-list {
  display: flex;
  justify-content: space-between;
  align-items:center;
  width: 320px;
  height: 60px;
}

.nav .nav-list .nav-item {
  color: rgba(255, 255, 255, 0.8);
  cursor: pointer;
}

.nav .nav-list .nav-item .dropdown-link {
  color: rgba(255, 255, 255, 0.8);
  font-size: 16px;
}

.go-register {
  float: left;
}

.go-register .link {
  font-size: 14px;
  color: #409EFF;
  line-height: 40px;
}
</style>
