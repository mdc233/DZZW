export const BASIC_REQUEST_URL = 'http://localhost:5000'
