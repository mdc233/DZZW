import axios from 'axios'

const request = (url, params = {}, method = 'GET') => {
  return axios({
    url: url,
    data: params,
    method
  }).then(res => {
    if (res.status === 200) {
      return res.data
    }
  })
}

export default request
