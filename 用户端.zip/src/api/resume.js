import request from './request'

/**
 * 添加简历信息
 * @param {Object} params 必需
 */
const addResume = (params) => {
  return request('/api/resume', params, 'POST')
}

const getResumeInfo = (userId) => {
  return request(`/api/resume/${userId}`)
}

const updateResumeInfo = (params) => {
  return request('/api/resume', params, 'PUT')
}

export {
  addResume,
  getResumeInfo,
  updateResumeInfo
}
