import request from './request'

const deliverResume = (params) => {
  return request('/api/interview/delivery', params, 'POST')
}

const getInterviewInfoByUserId = (userId) => {
  return request(`/api/interview/user/${userId}`, {}, 'GET')
}

export {
  deliverResume,
  getInterviewInfoByUserId
}
