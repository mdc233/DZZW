import request from './request'

const login = (email, password) => {
  return request('/api/user/login', { email, password }, 'POST')
}

const register = (email, password, name, schoolNum) => {
  return request('/api/user/register', { email, password, name, schoolNum }, 'POST')
}

export {
  login,
  register
}
