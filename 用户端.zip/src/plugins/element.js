import Vue from 'vue'
import { Button, Header, Container, Main, Carousel, CarouselItem, Aside, Menu, MenuItem, Dialog, Form, FormItem, Input, Upload, Dropdown, DropdownMenu, DropdownItem, DatePicker } from 'element-ui'

Vue.use(Button).use(Header).use(Container).use(Main).use(Carousel).use(CarouselItem).use(Aside).use(Menu).use(MenuItem).use(Dialog).use(Form).use(FormItem).use(Input).use(Upload).use(Dropdown).use(DropdownMenu).use(DropdownItem).use(DatePicker)
