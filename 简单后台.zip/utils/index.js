const crypto = require('crypto')
const md5Utils = function(content) {
  const md5 = crypto.createHash('md5')
  md5.update(content)
  return md5.digest('hex')
}

const validateUtils = {
  checkEmail(email) {
    let pattern = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/
    return pattern.test(email)
  },
  checkPassword(password) {
    let pattern = /^[a-zA-Z0-9_-]{8,32}$/
    return pattern.test(password)
  },
  checkNull(s) {
    return typeof s === 'undefined' || s === null
  }
}
module.exports = {
  md5Utils,
  validateUtils
}