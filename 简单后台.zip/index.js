const Koa = require('koa')
const logger = require('koa-logger')
const koaBody = require('koa-body')

const { catchError } = require('./middleware')

require('./database/init')
const userRouter = require('./routers/user')
const resumeRouter = require('./routers/resume')
const interviewRouter = require('./routers/interview')

const app = new Koa()


app.use(catchError)

app.use(logger())

app.use(koaBody({
  multipart: true,
  formidable: {
    maxFileSize: 50 * 1024 * 1024
  }
}))

app.use(userRouter.routes()).use(userRouter.allowedMethods())
app.use(resumeRouter.routes()).use(resumeRouter.allowedMethods())
app.use(interviewRouter.routes()).use(interviewRouter.allowedMethods())

app.listen(5000, () => {
  console.log('server listen in 5000')
})