### API

* 注册

  url: ` /user/register`

  method: `post`

  request:

  ```json
  email必需
  password 必需
  schoolNum必需
  name 必需
  ```

  response:

  ```
  {
      code: 0, 0表示成功,1表示出错
      data: {
          msg: '注册成功'
      }
  }
  ```

* 登录

  url: `/user/login`

  method: `post`

  request:

  ```
  email 必需
  password 必需
  ```

  response:

  ```
  {
      code: 0,
      data: {
          user:{
              id: 'xxx',
              name: 'xxx',
              schoolNum: 'xxx',
              email: 'xxx'
          }
      }
  }
  ```

* 创建简历

  url: `/resume`

  method: `POST`

  request:

  ```
  String userId // 用户id，必须
  String name // 用户真实姓名 必须
  String grade // 年级 必需
  String major // 专业 必需
  String projectExperience // 项目经历
  String internshipExperience // 实习经历
  String campusActivityExperience // 校园活动经历
  String skill // 技能
  String selfEvaluation // 自我评价
  String resumeUrl // 简历url
  ```

  response:

  ```
  {
  	code: 0,
  	data: {
          msg: '创建简历成功'
  	}
  }
  ```

* 获取简历信息

  url: `/resume`

  method: `get`

  request:

  ```
  String id // 简历id
  ```

  response:

  ```
  {
      code: 0,
      data: {
          // 简历信息
      }
  }
  ```

  

* 修改简历

  url: `/resmue`

  method: `PUT`

  request: 

  ```
  String id // 简历id，必须
  String name // 用户真实姓名 必须
  String grade // 年级 必需
  String major // 专业 必需
  String projectExperience // 项目经历
  String internshipExperience // 实习经历
  String campusActivityExperience // 校园活动经历
  String skill // 技能
  String selfEvaluation // 自我评价
  String resumeUrl // 简历url
  ```

  response:

  ```
  {
      code: 0,
      data: {
          msg: ‘修改简历成功'
      }
  }
  ```

  