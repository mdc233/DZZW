const Router = require('koa-router')

const InterviewController = require('../controllers/interview')

let router = new Router({
  prefix: '/api/interview'
})




router.get('/list', InterviewController.getAllInterview)

router.get('/user/:userId', InterviewController.getInterviewsDetail)

router.get('/completed', InterviewController.getCompletedInterview)

router.get('/uncompleted', InterviewController.getUnCompletedInterview)

router.get('/:id', InterviewController.getInterviewDetail)

router.post('/delivery', InterviewController.deliverResume)

router.post('/arrange', InterviewController.arrangeInterview)

router.post('/pass', InterviewController.passInterview)

router.post('/over', InterviewController.overInterview)

module.exports = router