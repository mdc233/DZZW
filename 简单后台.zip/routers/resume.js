const Router = require('koa-router')

const ResumeController = require('../controllers/resume')
const router = new Router({
  prefix: '/api'
})



router.post('/resume', ResumeController.addResumeInfo)
router.get('/resume/:userId', ResumeController.getResumeInfo)
router.put('/resume', ResumeController.editResumeInfo)

router.post('/resume/upload', ResumeController.uploadResume)
router.get('/resume/download/:userId', ResumeController.downloadResume)

module.exports = router