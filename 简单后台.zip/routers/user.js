const Router = require('koa-router')
const UserController = require('../controllers/user')

const router = new Router({
  prefix: '/api/user'
})

router.post('/login', UserController.login)

router.post('/register', UserController.register)



module.exports = router