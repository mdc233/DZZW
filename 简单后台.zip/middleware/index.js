async function catchError(ctx, next) {
  try {
    await next();
    if (ctx.status === 404) ctx.throw(404);
  } catch(err) {
    let status = err.status || 500;
    // let message = e.message || 'Server Error!'
    ctx.status = status;
    ctx.state = {
      status: status,
    };
    ctx.body = {
      error: 1,
      data: {
        msg: '服务器出错'
      }
    }
    if (status == 500) {
      console.log('server error', err, ctx);
    }
  }
}

module.exports = {
  catchError
} 
  