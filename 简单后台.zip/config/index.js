const DB_URL = 'mongodb://localhost:27017/matrix-test'

module.exports = {
  DB_URL
}