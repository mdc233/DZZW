const mongoose = require('mongoose')
const ObjectId = mongoose.Schema.Types.ObjectId

const ResumeSchema = mongoose.Schema({
  userId: {
    type: ObjectId,
    required: true,
    ref: 'User'
  },
  // 姓名
  name: {
    type: String,
    required: true
  },
  // 年级
  grade: {
    type: String,
    required: true,
  },
  // 院系
  department: {
    type: String,
    required: true
  },
  // 专业
  major: {
    type: String,
    required: true
  },
  // 项目经历
  projectExperience: {
    type: String,
    default: ''
  },
  // 实习经历
  internshipExperience: {
    type: String,
    default: ''
  },
  // 校园活动经历
  campusActivityExperience:{
    type: String,
    default: ''
  },
  // 自身技能
  skill: {
    type: String,
    default: ''
  },
  // 自我评价
  selfEvaluation:{
    type: String,
    default: ''
  },
  // 简历附件的url地址
  resumeUrl: {
    type: String,
    default: ''
  },
})

mongoose.model('Resume', ResumeSchema)