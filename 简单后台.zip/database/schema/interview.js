const mongoose = require('mongoose')

const ObjectId = mongoose.Schema.Types.ObjectId

const InterviewSchema = mongoose.Schema({
  userId: {
    type: ObjectId,
    required: true,
    ref: 'BasicUserInfo'
  },
  jobId: {
    type: Number,
    required: true
  },
  applyJob: {
    type: String,
    required: true
  },
  // 投递人姓名
  name: String,
  // 面试地点
  interviewLoc: {
    type: String,
    default: '数据科学与计算机学院楼A302实验室'
  },
  // 投递时间
  deliveryTime: {
    type: Date,
    default: Date.now()
  },
  // 近期空闲时间
  freeTime: Date,
  remark: String,
  interviewStatus: {
    type: Number,
    default: 1
  },
  interviewTime: Date
})

mongoose.model('Interview', InterviewSchema)