const mongoose = require('mongoose')

var UserSchema = mongoose.Schema({
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true,
  }, // 姓名
  schoolNum: {
    type: Number,
    required: true
  },
  jobIds: [Number], // 申请的职位
  isCreateResume: {
    type: Boolean,
    default: false
  } // 是否创建了简历
})

mongoose.model('User', UserSchema)