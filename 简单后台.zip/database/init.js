const mongoose = require('mongoose')

const DB_URL = require('../config').DB_URL

mongoose.Promise = global.Promise

;(() => {
  console.log('init schema')
  require('./schema')
})()

mongoose.connect(DB_URL)

mongoose.connection.once('open', () => {
  console.log('数据库连接成功')
})

mongoose.connection.on('error', () => {
  console.log('数据库连接出错')
})