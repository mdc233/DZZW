const fs = require('fs')
const path = require('path')
const mongoose = require('mongoose')
const { validateUtils } = require('../utils')
const Resume = mongoose.model('Resume')
const User = mongoose.model('User')

const ResumeController = {
  async addResumeInfo (ctx, next) {
    let { 
      userId, 
      name, 
      grade, 
      department,
      major,
      // 项目经历
      projectExperience = '',
      // 实习经历
      internshipExperience = '',
      // 校园活动经历
      campusActivityExperience = '',
      // 自身技能
      skill = '',
      // 自我评价
      selfEvaluation = '',
      // 简历的url地址
      resumeUrl = ''
    } = ctx.request.body

    if (validateUtils.checkNull(userId)) {
      ctx.body = {
        code: 1,
        data: {
          msg: '缺少用户id'
        }
      }
      return
    }

    if (validateUtils.checkNull(name)) {
      ctx.body = {
        code: 1,
        data: {
          msg: '缺少姓名'
        }
      }
      return
    }

    if (validateUtils.checkNull(department)) {
      ctx.body = {
        code: 1,
        data: {
          msg: '缺少学院'
        }
      }
    }

    if (validateUtils.checkNull(major)) {
      ctx.body = {
        code: 1,
        data: {
          msg: '缺少专业'
        }
      }
    }

    if (validateUtils.checkNull(grade)) {
      ctx.body = {
        code: 1,
        data: {
          msg: '缺少年级'
        }
      }
    }
    
    let resume = new Resume({
      userId, 
      name, 
      grade,
      major,
      department,
      // 项目经历
      projectExperience,
      // 实习经历
      internshipExperience,
      // 校园活动经历
      campusActivityExperience,
      // 自身技能
      skill,
      // 自我评价
      selfEvaluation,
      // 简历的url地址
      resumeUrl
    })
    let result = await resume.save()
    if (result) {
      console.log(result)
      let user = await User.findOne({_id: userId})
      user.isCreateResume = true
      let re = user.save()
      if (re) {
        ctx.body = {
          code: 0,
          data: {
            msg: '简历创建成功',
            resume: result
          }
        }
      }
    } else {
      ctx.body = {
        code: 1,
        data: {
          msg: '简历创建失败'
        }
      }
    }
  },
  async getResumeInfo (ctx, next) {
    let { userId } = ctx.params
    if (userId.length !== 24) {
      ctx.body = {
        code: 1,
        data: {
          msg: 'id格式不正确'
        }
      }
      return
    }
    let resume = await Resume.findOne({ userId })
    if (resume) {
      ctx.body = {
        code: 0,
        data: {
          resume
        }
      }
    } else {
      ctx.body = {
        code: 1,
        data: {
          msg: '暂无相关简历'
        }
      }
    }
  },
  async editResumeInfo (ctx, next) {
    console.log(ctx.request.body)
    let { 
      userId, 
      name, 
      grade, 
      department,
      major,
      // 项目经历
      projectExperience = '',
      // 实习经历
      internshipExperience = '',
      // 校园活动经历
      campusActivityExperience = '',
      // 自身技能
      skill = '',
      // 自我评价
      selfEvaluation = '',
      // 简历的url地址
      resumeUrl = ''
    } = ctx.request.body

    let resume = await Resume.findOne({ userId })
    resume.name = name || resume.name
    resume.grade = grade || resume.grade
    resume.department = department || resume.department
    resume.major = major || resume.major
    resume.projectExperience = projectExperience || resume.projectExperience
    resume.internshipExperience = internshipExperience || resume.internshipExperience
    resume.campusActivityExperience = campusActivityExperience || resume.campusActivityExperience
    resume.skill = skill || resume.skill
    resume.selfEvaluation = selfEvaluation || resume.selfEvaluation
    resume.resumeUrl = resumeUrl || resume.resumeUrl
    let result = await resume.save()
    console.log(result)
    ctx.body = {
      code: 0,
      data: {
        msg: '更新简历成功'
      }
    }
  },
  async uploadResume (ctx, next) {
    let { userId } = ctx.request.query
    let file = ctx.request.files.file
    let reader = fs.createReadStream(file.path)
    let filePath = path.resolve(__dirname, '../upload', userId)
    let writer = fs.createWriteStream(filePath)
    reader.pipe(writer)
    ctx.body = {
      code: 0,
      data: {
        msg: '上传成功',
        userId: userId
      }
    }
  },
  async downloadResume (ctx, next) {
    let { userId } = ctx.params
    let filePath = path.resolve(__dirname, '../upload', userId)
    let stream = fs.createReadStream(filePath)
    ctx.type = 'pdf'
    ctx.body = stream
  }
}

module.exports = ResumeController