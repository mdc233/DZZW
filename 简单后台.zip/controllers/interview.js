const mongoose = require('mongoose')

const Interview = mongoose.model('Interview')
const User = mongoose.model('User')

const InterviewController = {
  getAllInterview: async function (ctx, next) {
    let {page = 1, count = 10, status, jobId } = ctx.request.query
    page = parseInt(page)
    count = parseInt(count)
    let condition = {}
    if (jobId) {
      condition.jobId = jobId
    }
    if (status) {
      condition.interviewStatus = status
    }
    let interviews = await Interview.find(condition).skip((page - 1) * count).limit(count)
    let total = await Interview.count(condition)
    if (interviews) {
      ctx.body = {
        code: 0,
        data: {
          interviews,
          page,
          count,
          total
        }
      }
    }
  },
  getCompletedInterview: async function (ctx, next) {
    let {page = 1, count = 10, jobId } = ctx.request.query
    page = parseInt(page)
    count = parseInt(count)
    let condition = { interviewStatus: {$gt: 2}}
    if (jobId) {
      condition.jobId = jobId
    }
    let interviews = await Interview.find(condition).skip((page - 1) * count).limit(count).sort('deleveryTime')
    let total = await Interview.count(condition)
    if (interviews) {
      ctx.body = {
        code: 0,
        data: {
          interviews,
          page,
          count,
          total
        }
      }
    }
  },
  getUnCompletedInterview: async function (ctx, next) {
    let {page = 1, count = 10, jobId } = ctx.request.query
    page = parseInt(page)
    count = parseInt(count)
    let condition = { interviewStatus: {$lt: 3}}
    if (jobId) {
      condition.jobId = jobId
    }
    let interviews = await Interview.find(condition).skip((page - 1) * count).limit(count).sort('deleveryTime')
    let total = await Interview.count(condition)
    if (interviews) {
      ctx.body = {
        code: 0,
        data: {
          interviews,
          page,
          count,
          total
        }
      }
    }
  },
  getInterviewsDetail: async function(ctx, next) {
    let { userId } = ctx.params
    let interviews = await Interview.find({ userId })
    if (interviews) {
      ctx.body = {
        code: 0,
        data: {
          interviews
        }
      }
    }
  },
  getInterviewDetail: async function(ctx, next) {
    let { id } = ctx.params
    let interview = await Interview.findOne({ _id: id })
    if (interview) {
      ctx.body = {
        code: 0, 
        data: {
          interview
        }
      }
    }
  },
  deliverResume: async function(ctx, next) {
    let {
      userId,
      jobId,
      name,
      applyJob,
      interviewLoc,
      freeTime,
      remark
    } = ctx.request.body
    let interview = new Interview({
      userId,
      jobId,
      name,
      applyJob,
      interviewLoc,
      freeTime,
      remark
    })
    let result = await interview.save()
    let user = await User.findOne({_id: userId})
    user.jobIds.push(jobId)
    await user.save()
    console.log(result)
    if (result) {
      ctx.body = {
        code: 0,
        data: {
          msg: '投递简历成功'
        }
      }
    }
  },
  arrangeInterview: async function(ctx, next) {
    let {
      id,
      interviewTime
    } = ctx.request.body
    let interview = await Interview.findOne({_id: id})
    interview.interviewTime = interviewTime
    interview.interviewStatus = 2
    let result = await interview.save()
    if (result) {
      ctx.body = {
        code: 0,
        data: {
          msg: '安排面试成功'
        }
      }
    }
  },
  passInterview: async function(ctx, next) {
    let { id } = ctx.request.body
    let interview = await Interview.findOne({_id: id})
    interview.interviewStatus = 3
    let result = await interview.save()
    if (result) {
      ctx.body = {
        code: 0,
        data: {
          msg: '操作成功'
        }
      }
    }
  },

  overInterview: async function(ctx, next) {
    let { id } = ctx.request.body
    let interview = await Interview.findOne({_id: id})
    interview.interviewStatus = 4
    let result = await interview.save()
    if (result) {
      ctx.body = {
        code: 0,
        data: {
          msg: '操作成功'
        }
      }
    }
  },
  __finishInterview: async function(ctx, next, status) {
    let { id } = ctx.request.body
    let interview = await Interview.findOne({_id: id})
    interview.interviewStatus = status
    let result = await interview.save()
    if (result) {
      ctx.body = {
        code: 0,
        data: {
          msg: '操作成功'
        }
      }
    }
  }
}

module.exports = InterviewController