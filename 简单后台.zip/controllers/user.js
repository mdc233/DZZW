const mongoose = require('mongoose')
const { md5Utils, validateUtils } = require('../utils')

const User = mongoose.model('User')

const UserController = {
  async login (ctx, next) {
    let {email, password} = ctx.request.body
    password = md5Utils(password)
    let result = await User.findOne({email, password})
    if (result) {
      ctx.body = {
        code: 0,
        data: {
          user: {
            id: result._id,
            email: result.email,
            name: result.name,
            isCreateResume: result.isCreateResume,
            schoolNum: result.schoolNum,
            jobIds: result.jobIds
          }
        }
      }
    } else {
      ctx.body = {
        code: 1,
        data: {
          msg: '邮箱或密码不正确'
        }
      }
    }
  },
  async register (ctx, next) {
    let {email, password, schoolNum, name} = ctx.request.body
    if (!validateUtils.checkEmail(email)) {
      ctx.body = {
        code: 1,
        data: {
          msg: '邮箱格式不正确'
        }
      }
      return
    }
    if (!validateUtils.checkPassword(password)) {
      ctx.body = {
        code: 1,
        data: {
          msg: '密码格式不规范'
        }
      }
      return
    }
    let hasRegister = await User.findOne({email})
    if (hasRegister) {
      ctx.body = {
        code: 1,
        data: {
          msg: '该邮箱已被注册'
        }
      }
      return 
    }
    password = md5Utils(password)
    let user = new User({
      email,
      password,
      schoolNum,
      name
    })
    let result = await user.save()
    if (result) {
      ctx.body = {
        code: 0,
        data: {
          msg: '注册成功'
        }
      }
    } else {
      ctx.body = {
        code: 1,
        data: {
          msg: '注册失败'
        }
      }
    }
  }
}

module.exports = UserController